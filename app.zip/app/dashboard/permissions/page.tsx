"use client";
import Button from "@/components/Button/Button";
import Modal from "@/components/Modal/Modal";
import React, { useState } from "react";

// Types for Role, Module, and Permissions
interface Role {
  id: number;
  name: string;
}

interface Module {
  name: string;
}

interface Permissions {
  [key: string]: {
    read: boolean;
    write: boolean;
    delete: boolean;
  };
}

const PermissionsPage: React.FC = () => {
  // Mock data for roles and modules
  const roles: Role[] = [
    { id: 1, name: "Admin" },
    { id: 2, name: "Librarian" },
    { id: 3, name: "Library Assistant" },
  ];

  const initialModules: Module[] = [
    { name: "Books" },
    { name: "Users" },
    { name: "Members" },
  ];

  // State for selected role
  const [selectedRole, setSelectedRole] = useState<number>(roles[0].id);
  const [permissions, setPermissions] = useState<Permissions>({
    Books: { read: true, write: true, delete: true },
    Users: { read: true, write: false, delete: false },
    Members: { read: true, write: false, delete: false },
  });

  const [modules, setModules] = useState<Module[]>(initialModules);

  // State for modal visibility and form inputs
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [newModuleName, setNewModuleName] = useState<string>("");

  // Handlers
  const handleRoleSelection = (roleId: number) => {
    setSelectedRole(roleId);
    // Reset permissions for demo (or load role-specific permissions here)
    setPermissions({
      Books: { read: true, write: true, delete: true },
      Users: { read: true, write: false, delete: false },
      Members: { read: true, write: false, delete: false },
    });
  };

  const handlePermissionChange = (
    module: string,
    action: "read" | "write" | "delete"
  ) => {
    setPermissions((prev) => ({
      ...prev,
      [module]: {
        ...prev[module],
        [action]: !prev[module][action],
      },
    }));
  };

  const handleSave = () => {
    console.log("Saved Permissions for Role:", selectedRole);
    console.log(permissions);
    alert("Permissions saved successfully!");
  };

  const handleOpenModal = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setNewModuleName("");
  };

  const handleAddModule = () => {
    if (newModuleName.trim()) {
      setModules((prev) => [...prev, { name: newModuleName }]);
      setPermissions((prev) => ({
        ...prev,
        [newModuleName]: { read: false, write: false, delete: false },
      }));
      handleCloseModal();
    } else {
      alert("Module name cannot be empty!");
    }
  };

  // Selected role name
  const selectedRoleName = roles.find((role) => role.id === selectedRole)?.name;

  return (
    <section className="permissions-page">
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b border-gray-200">
        <h1 className="text-2xl font-bold">Permissions Management</h1>
        <nav>
          <ul className="flex gap-2 text-gray-500">
            <li>Dashboard</li>
            <li>/</li>
            <li>Permissions</li>
          </ul>
        </nav>
      </header>

      {/* Main Content */}
      <div className="flex flex-col lg:flex-row">
        {/* Role Selector Panel */}
        <aside className="w-full lg:w-1/4 border-b lg:border-r border-gray-200 p-4">
          <h2 className="text-lg font-semibold mb-4">Select Role</h2>
          <ul className="space-y-2">
            {roles.map((role) => (
              <li
                key={role.id}
                className={`p-2 cursor-pointer rounded-md hover:bg-gray-100 ${
                  selectedRole === role.id ? "bg-gray-100 font-bold" : ""
                }`}
                onClick={() => handleRoleSelection(role.id)}
              >
                {role.name}
              </li>
            ))}
          </ul>
        </aside>

        {/* Permission Grid */}
        <main className="w-full lg:w-3/4 p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">
              Permissions for {selectedRoleName}
            </h2>
            <Button
              buttonName="Add Permission"
              className="bg-green-500 text-white hover:bg-green-600"
              onClick={handleOpenModal}
            />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full table-auto border-collapse">
              <thead>
                <tr>
                  <th className="border border-gray-300 p-2 text-left">
                    Module
                  </th>
                  <th className="border border-gray-300 p-2 text-center">
                    Read
                  </th>
                  <th className="border border-gray-300 p-2 text-center">
                    Write
                  </th>
                  <th className="border border-gray-300 p-2 text-center">
                    Delete
                  </th>
                </tr>
              </thead>
              <tbody>
                {modules.map((module) => (
                  <tr key={module.name}>
                    <td className="border border-gray-300 p-2">
                      {module.name}
                    </td>
                    <td className="border border-gray-300 p-2 text-center">
                      <input
                        type="checkbox"
                        checked={permissions[module.name]?.read || false}
                        onChange={() =>
                          handlePermissionChange(module.name, "read")
                        }
                      />
                    </td>
                    <td className="border border-gray-300 p-2 text-center">
                      <input
                        type="checkbox"
                        checked={permissions[module.name]?.write || false}
                        onChange={() =>
                          handlePermissionChange(module.name, "write")
                        }
                      />
                    </td>
                    <td className="border border-gray-300 p-2 text-center">
                      <input
                        type="checkbox"
                        checked={permissions[module.name]?.delete || false}
                        onChange={() =>
                          handlePermissionChange(module.name, "delete")
                        }
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </main>
      </div>

      {/* Footer */}
      <footer className="p-4 border-t border-gray-200 flex justify-end">
        <Button
          buttonName="Save Changes"
          className="bg-blue-500 text-white hover:bg-blue-600"
          onClick={handleSave}
        />
      </footer>

      {/* Add Permission Modal */}
      {isModalOpen && (
        <Modal>
          <h3 className="text-xl font-semibold mb-4">Add New Permission</h3>
          <div className="mb-4">
            <label className="block mb-2 font-medium">Module Name</label>
            <input
              type="text"
              className="w-full p-2 border border-gray-300 rounded-md"
              value={newModuleName}
              onChange={(e) => setNewModuleName(e.target.value)}
            />
          </div>
          <div className="flex justify-end gap-4">
            <Button
              buttonName="Cancel"
              className="bg-gray-500 text-white hover:bg-gray-600"
              onClick={handleCloseModal}
            />
            <Button
              buttonName="Add Permission"
              className="bg-blue-500 text-white hover:bg-blue-600"
              onClick={handleAddModule}
            />
          </div>
        </Modal>
      )}
    </section>
  );
};

export default PermissionsPage;
