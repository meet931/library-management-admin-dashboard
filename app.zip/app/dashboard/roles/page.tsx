"use client";
import Button from "@/components/Button/Button";
import Modal from "@/components/Modal/Modal";
import IconService from "@/utils/icon";
import Image from "next/image";
import React, { useState } from "react";

const RoleManagementPage: React.FC = () => {
  // Mock data for roles and permissions
  const initialRoles = [
    { id: 1, name: "Manager", description: "Full access to all modules" },
    { id: 2, name: "Librarian", description: "Manage books and members" },
    {
      id: 3,
      name: "Library Assistant",
      description: "View-only access to books and members",
    },
  ];

  const permissionsList = ["Books", "Users", "Members"];

  // State for roles, selected role, and modal visibility
  const [roles, setRoles] = useState(initialRoles);  
  const [isModalOpen, setIsModalOpen] = useState(false);

  // State for new/edit role form
  const [roleForm, setRoleForm] = useState({
    id: null,
    name: "",
    description: "",
    permissions: [], // Ensure permissions are always an array
  });

  // Handlers
  const handleOpenModal = (role) => {
    const roleToEdit = role
      ? { ...role, permissions: role.permissions || [] } // Ensure permissions are always an array
      : { id: null, name: "", description: "", permissions: [] }; // New role initialization

    setRoleForm(roleToEdit);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setRoleForm((prev) => ({ ...prev, [name]: value }));
  };

  const handlePermissionChange = (permission) => {
    setRoleForm((prev) => {
      const updatedPermissions = prev.permissions.includes(permission)
        ? prev.permissions.filter((perm) => perm !== permission)
        : [...prev.permissions, permission];
      return { ...prev, permissions: updatedPermissions };
    });
  };

  const handleSaveRole = () => {
    if (roleForm.id) {
      // Edit existing role
      setRoles((prev) =>
        prev.map((role) =>
          role.id === roleForm.id ? { ...role, ...roleForm } : role
        )
      );
    } else {
      // Add new role
      const newRole = {
        ...roleForm,
        id: roles.length + 1,
      };
      setRoles((prev) => [...prev, newRole]);
    }
    handleCloseModal();
  };

  const handleDeleteRole = (id) => {
    setRoles((prev) => prev.filter((role) => role.id !== id));
  };

  return (
    <section className="role-management-page">
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b border-gray-200">
        <h1 className="text-2xl font-bold">Role Management</h1>
        <nav>
          <ul className="flex gap-2 text-gray-500">
            <li>Dashboard</li>
            <li>/</li>
            <li>Roles</li>
          </ul>
        </nav>
      </header>

      <div className=" flex justify-end p-4">
        <Button
          buttonName="Add New Role"
          className="bg-blue-500 text-white hover:bg-blue-600"
          onClick={() => handleOpenModal(null)}
        />
      </div>

      {/* Role List */}
      <div className="p-4">
        <h2 className="text-lg sm:text-xl lg:text-2xl font-semibold mb-4">
          Roles
        </h2>
        <table className="w-full table-auto border-collapse border border-gray-300">
          <thead>
            <tr>
              <th className="border border-gray-300 p-2">Role Name</th>
              <th className="border border-gray-300 p-2">Description</th>
              <th className="border border-gray-300 p-2">Permissions</th>
              <th className="border border-gray-300 p-2 text-center">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {roles.map((role) => (
              <tr key={role.id}>
                <td className="border border-gray-300 p-2">{role.name}</td>
                <td className="border border-gray-300 p-2">
                  {role.description}
                </td>
                <td className="border border-gray-300 p-2">
                  {(role.permissions || []).join(", ") || "No Permissions"}
                </td>
                <td className="border border-gray-300 p-2 text-center">
                  <button
                    className="text-blue-500 hover:underline mr-2"
                    onClick={() => handleOpenModal(role)}
                  >
                    <Image
                      src={IconService.edit_icon.src}
                      width={20}
                      height={20}
                      alt="Roles"
                    />
                  </button>
                  <button
                    className="text-red-500 hover:underline"
                    onClick={() => handleDeleteRole(role.id)}
                  >
                    <Image
                      src={IconService.delete_icon.src}
                      width={20}
                      height={20}
                      alt="Roles"
                    />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Role Modal */}
      {isModalOpen && (
        <Modal>
          <h3 className="text-xl sm:text-2xl font-semibold mb-4">
            {roleForm.id ? "Edit Role" : "Add New Role"}
          </h3>
          <div className="mb-4">
            <label className="block mb-2 font-medium">Role Name</label>
            <input
              type="text"
              name="name"
              className="w-full p-2 border border-gray-300 rounded-md"
              value={roleForm.name}
              onChange={handleFormChange}
            />
          </div>
          <div className="mb-4">
            <label className="block mb-2 font-medium">Description</label>
            <textarea
              name="description"
              className="w-full p-2 border border-gray-300 rounded-md"
              value={roleForm.description}
              onChange={handleFormChange}
            />
          </div>
          <div className="mb-4">
            <label className="block mb-2 font-medium">Permissions</label>
            <div className="flex flex-wrap gap-2">
              {permissionsList.map((permission) => (
                <label
                  key={permission}
                  className="flex items-center gap-2 text-sm sm:text-base"
                >
                  <input
                    type="checkbox"
                    checked={roleForm.permissions.includes(permission)}
                    onChange={() => handlePermissionChange(permission)}
                  />
                  {permission}
                </label>
              ))}
            </div>
          </div>
          <div className="flex justify-end gap-4">
            <Button
              buttonName="Cancel"
              className="bg-gray-500 text-white hover:bg-gray-600"
              onClick={handleCloseModal}
            />
            <Button
              buttonName="Save Role"
              className="bg-blue-500 text-white hover:bg-blue-600"
              onClick={handleSaveRole}
            />
          </div>
        </Modal>
      )}
    </section>
  );
};

export default RoleManagementPage;
