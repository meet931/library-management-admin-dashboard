import Login from "./auth/login/page";

export default function Home() {
  return (
    <div>
      <Login />
    </div>
  );
}
