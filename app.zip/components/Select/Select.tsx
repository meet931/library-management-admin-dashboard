import React, { FC, SelectHTMLAttributes } from "react";

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  labelName?: string;
  labelClass?: string;
  value?: string;
  contentList?: string[];
  option?: string;
  onChange?: (event: React.ChangeEvent<HTMLSelectElement>) => void;
  className?: string;
  errorMessage?: string;
}

const Select: FC<SelectProps> = ({
  labelName,
  labelClass,
  value,
  contentList = [], // Initialize options with an empty array
  option,
  onChange,
  className,
  errorMessage,
  ...props
}) => {
  return (
    <div>
      {labelName && (
        <label className={`block mb-2 font-medium ${labelClass}`}>
          {labelName}
        </label>
      )}
      <select
        className={`w-full p-2 pr-8 border border-gray-300 rounded-md ${className}`}
        value={value}
        onChange={onChange}
      >
        {option && <option value="">{option}</option>}
        {contentList.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
      {errorMessage && (
        <p className="text-sm text-red-600 mt-1">{errorMessage}</p>
      )}
    </div>
  );
};

export default Select;

